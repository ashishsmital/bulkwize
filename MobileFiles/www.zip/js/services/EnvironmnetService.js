/**
 * Created by ghanavela on 3/19/2016.
 */

app.constant('EnvConfig', (function() {
    // Define your variable
    var devResource = 'http://52.73.228.44:8080/';
    // Use the variable in your constants
    return {
        HOST: devResource,
    }
})());
