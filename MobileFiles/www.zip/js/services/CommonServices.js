/**
 * Created by ghanavela on 3/13/2016.
 */
app.factory('CommonServices', function () {

    var CommonServices = {


    }
    return CommonServices;
})